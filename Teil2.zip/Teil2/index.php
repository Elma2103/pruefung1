<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Navigation</h1>
    <ul>
        <li><a href="index.html">Zurück zur Startseite</a></li>
        <li><a href="voting.php">Zu den Votings</a></li>
    </ul>

    <form method="post">
    <label for="dropDownList">Marke</label>
     <select name="marke">
        <option value=""></option>
        <option value="Maestro 10">Maestro 10</option>
        <option value="E50i">E50i</option>
        <option value="Bio S">Bio S</option>
        <option value="TRX 7500 iQ VORTRAX">TRX 7500 iQ VORTRAX</option>
        <option value="Alpha 63 IQ BIO">Alpha 63 IQ BIO</option>
    </select>
    <label for="dropDownList">Nutzungsart</label>
     <select name="nutzungsart">
        <option value=""></option>
        <option value="öffentliche Anlagen">öffentliche Anlagen</option>
        <option value="private Anlagen">private Anlagen</option>
        <option value="semi-öffentliche Anlagen">semi-öffentliche Anlagen</option>
    </select>
    <label for="dropDownList">Poolart</label>
    <select name="poolart">
        <option value=""></option>
        <option value="naturpool">Naturpool</option>
        <option value="schwimmteich">Schwimmteich</option>
        <option value="swimmingpool">Swimming Pool</option>
    </select>
<input type="submit" value="filtern">
</form>



<?php
//Verbindung zur Datenbank herstellen
$servername = "localhost";
$username = "root";
$password = "";
$database = "poolroboter";

//Neue Datenbankverbindung erstellen
$conn = new mysqli ($servername, $username, $password, $database);

//Überprüfung der Verbindung
if ($conn->connect_error) {
    die ("Verbindung zur Datenbank fehlgeschlagen:" . $conn->connect_error);
}

//
$where = "";
if (count($_POST)>0){
    $arr = [];
    if($_POST["marke"] ==! null ){
        $arr[] = "tbl_marken.Marke = '".$_POST["marke"]."'";
    }
    if($_POST["nutzungsart"] ==! null){
        $arr[] = "tbl_nutzungsarten.Nutzungsart = '".$_POST["nutzungsart"]."'";
    }
    if($_POST["poolart"] ==! null){
        $arr[] = "tbl_poolarten.Poolart = '".$_POST["poolart"]."'";
    }
    if(count($arr)> 0){
        $where = "WHERE (
            ".implode("AND ", $arr)."
            )";
    }
    else {
        $where = "";
    }
}


//SQL-Abfrage

$sql = "SELECT
tbl_poolroboter.Poolroboter,
tbl_poolroboter.Beschreibung,
tbl_poolroboter.Artikelnummer,
tbl_marken.Marke,
tbl_poolarten.Poolart,
tbl_nutzungsarten.Nutzungsart
FROM tbl_poolroboter
INNER JOIN tbl_marken ON tbl_poolroboter.FIDMarke = tbl_marken.IDMarke
INNER JOIN tbl_poolarten ON tbl_poolroboter.FIDPoolart = tbl_poolarten.IDPoolart
INNER JOIN tbl_nutzungsarten ON tbl_poolroboter.FIDNutzungsart = tbl_nutzungsarten.IDNutzungsart
ORDER BY tbl_marken.Marke ASC, tbl_poolroboter.Beschreibung ASC
".$where."
";

$result = $conn->query($sql) or die ("Fehler".$conn->error."");



while ($row = $result->fetch_object()){
    echo ('<br>'. $row->Marke .'<br>' . $row->Poolroboter .'<br>' .$row->Artikelnummer . '<br>' . $row->Beschreibung . '<br>' . $row->Poolart .
    $row->Nutzungsart . '<br>');

 } 

$conn->close();

?>
</body>
</html>