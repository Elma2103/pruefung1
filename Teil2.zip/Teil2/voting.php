<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Navigation</h1>
    <ul>
        <li><a href="index.html">Zurück zur Startseite</a></li>
        <li><a href="index.php">Zu den Robotern</a></li>
    </ul>

<form method="post">
    <label for="dropDownList">Welche Marke möchten Sie bewerten</label>
     <select name="marke">
        <option value=""></option>
        <option value="Dolphin">Dolphin</option>
        <option value="Zodiac">Zodiac</option>
    </select>

<label for="user">User</label>
<input type="text" name="user"> 

<label for="dropDownList">Ihre Bewertung</label>
     <select name="skala">
        <option value=""></option>
        <option value="1">schlecht</option>
        <option value="2">ausreichend</option>
        <option value="3">befriedigend</option>
        <option value="4">gut</option>
        <option value="5">sehr gut</option>
        </select>

        <label for="bewertungstext"></label>
        <textarea name="bewertungstext" id="" cols="30" rows="10"></textarea>

        <input type="submit" value="filtern">
    </form>

<?php
//Verbindung zur Datenbank herstellen
$servername = "localhost";
$username = "root";
$password = "";
$database = "poolroboter";

//Neue Datenbankverbindung erstellen
$conn = new mysqli ($servername, $username, $password, $database);

//Überprüfung der Verbindung
if ($conn->connect_error) {
    die ("Verbindung zur Datenbank fehlgeschlagen:" . $conn->connect_error);
}
$where = "";
if (count($_POST)>0){
    $arr = [];
    if($_POST["marke"] ==! null){
        $arr[] = "tbl_marken.Marke = '".$_POST["marke"]."'";
    }
    if($_POST["skala"] ==! null){
        $arr[] = "tbl_skala.Wert = '".$_POST["skala"]."'";
    }
    if(count($arr)>0){
        $where = "WHERE (
            ".implode("AND ", $arr)."
            )";
    }
    else {
        $where = "";
    }
}

//SQL-Abfrage

$sql = "SELECT
tbl_votings.*,
tbl_marken.Marke,
tbl_votings.User,
tbl_votings.Bewertungstext, 
tbl_skala.Wert,
AVG (tbl_skala.Wert) AS Durchschnitt
FROM tbl_votings
LEFT JOIN tbl_marken ON tbl_votings.FIDMarke = tbl_marken.IDMarke
left JOIN tbl_skala ON tbl_votings.FIDBewertung = tbl_skala.IDSkala
ORDER BY tbl_marken.Marke ASC
".$where."
";

$result = $conn->query($sql) or die ("Fehler".$conn->error."");
if ($result->num_rows==0){
    $sql =
    "INSERT INTO tbl_votings
     (User, Bewertungstext) 
    VALUES (
    '" . $_POST["User"] . "',
     '" . $_POST["Bewertungstext"] . "'
    )
    ";
    $ok = $conn->query($sql);
if($ok) {
$msg = '<p class="success"> Erfolg </p>';
  }
}
while ($row = $result->fetch_object()){
    echo ('<br>'. (round($row->Durchschnitt)). '/' . $row->Wert .'Sterne' . $row->Marke .'<br>' .$row->User  .'<br>' .$row->Bewertungstext );

 } 

 $conn->close();
?>
</body>
</html>