-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 24. Jul 2023 um 15:24
-- Server-Version: 10.4.21-MariaDB
-- PHP-Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `speisekarte`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `allergene`
--

CREATE TABLE `allergene` (
  `IDAllergene` int(10) UNSIGNED NOT NULL,
  `Bezeichnung` varchar(10) NOT NULL,
  `Beschreibung` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gerichte`
--

CREATE TABLE `gerichte` (
  `IDGericht` int(10) UNSIGNED NOT NULL,
  `Name` varchar(128) NOT NULL,
  `Preis` decimal(5,2) NOT NULL,
  `FIDAllergene` int(10) UNSIGNED NOT NULL,
  `FIDMaßeinheit` int(10) UNSIGNED NOT NULL,
  `FIDHinweis` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hinweis`
--

CREATE TABLE `hinweis` (
  `IDHinweis` int(10) UNSIGNED NOT NULL,
  `Bezeichnung` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kategorie`
--

CREATE TABLE `kategorie` (
  `IDKategorie` int(10) UNSIGNED NOT NULL,
  `Name` varchar(28) NOT NULL,
  `FIDUnterkategorie` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `maßeinheit`
--

CREATE TABLE `maßeinheit` (
  `IDMaßeinheit` int(10) UNSIGNED NOT NULL,
  `Beschreibung` decimal(2,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `menü_der_woche`
--

CREATE TABLE `menü_der_woche` (
  `IDMenü` int(10) UNSIGNED NOT NULL,
  `Woche` date NOT NULL,
  `FIDGericht` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `speisekarte`
--

CREATE TABLE `speisekarte` (
  `IDSpeisekarte` int(10) UNSIGNED NOT NULL,
  `FIDGericht` int(10) UNSIGNED NOT NULL,
  `FIDMenüderWoche` int(10) UNSIGNED NOT NULL,
  `FIDKategorie` int(10) UNSIGNED NOT NULL,
  `FIDUnterkategorie` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `unterkategorie`
--

CREATE TABLE `unterkategorie` (
  `IDUnterkategorie` int(10) UNSIGNED NOT NULL,
  `Name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `allergene`
--
ALTER TABLE `allergene`
  ADD PRIMARY KEY (`IDAllergene`);

--
-- Indizes für die Tabelle `gerichte`
--
ALTER TABLE `gerichte`
  ADD PRIMARY KEY (`IDGericht`),
  ADD KEY `FIDAllergene` (`FIDAllergene`),
  ADD KEY `FIDMaßeinheit` (`FIDMaßeinheit`),
  ADD KEY `FIDHinweis` (`FIDHinweis`);

--
-- Indizes für die Tabelle `hinweis`
--
ALTER TABLE `hinweis`
  ADD PRIMARY KEY (`IDHinweis`);

--
-- Indizes für die Tabelle `kategorie`
--
ALTER TABLE `kategorie`
  ADD PRIMARY KEY (`IDKategorie`),
  ADD KEY `FIDUnterkategorie` (`FIDUnterkategorie`);

--
-- Indizes für die Tabelle `maßeinheit`
--
ALTER TABLE `maßeinheit`
  ADD PRIMARY KEY (`IDMaßeinheit`);

--
-- Indizes für die Tabelle `menü_der_woche`
--
ALTER TABLE `menü_der_woche`
  ADD PRIMARY KEY (`IDMenü`),
  ADD KEY `FIDGericht` (`FIDGericht`);

--
-- Indizes für die Tabelle `speisekarte`
--
ALTER TABLE `speisekarte`
  ADD PRIMARY KEY (`IDSpeisekarte`),
  ADD KEY `FIDGericht` (`FIDGericht`),
  ADD KEY `FIDMenüderWoche` (`FIDMenüderWoche`),
  ADD KEY `FIDKategorie` (`FIDKategorie`),
  ADD KEY `FIDUnterkategorie` (`FIDUnterkategorie`);

--
-- Indizes für die Tabelle `unterkategorie`
--
ALTER TABLE `unterkategorie`
  ADD PRIMARY KEY (`IDUnterkategorie`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `gerichte`
--
ALTER TABLE `gerichte`
  MODIFY `IDGericht` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `speisekarte`
--
ALTER TABLE `speisekarte`
  MODIFY `IDSpeisekarte` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `gerichte`
--
ALTER TABLE `gerichte`
  ADD CONSTRAINT `gerichte_ibfk_1` FOREIGN KEY (`FIDAllergene`) REFERENCES `allergene` (`IDAllergene`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gerichte_ibfk_2` FOREIGN KEY (`FIDHinweis`) REFERENCES `hinweis` (`IDHinweis`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gerichte_ibfk_3` FOREIGN KEY (`FIDMaßeinheit`) REFERENCES `maßeinheit` (`IDMaßeinheit`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `kategorie`
--
ALTER TABLE `kategorie`
  ADD CONSTRAINT `kategorie_ibfk_1` FOREIGN KEY (`FIDUnterkategorie`) REFERENCES `unterkategorie` (`IDUnterkategorie`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `speisekarte`
--
ALTER TABLE `speisekarte`
  ADD CONSTRAINT `speisekarte_ibfk_1` FOREIGN KEY (`FIDMenüderWoche`) REFERENCES `menü_der_woche` (`IDMenü`) ON UPDATE CASCADE,
  ADD CONSTRAINT `speisekarte_ibfk_2` FOREIGN KEY (`FIDKategorie`) REFERENCES `kategorie` (`IDKategorie`) ON UPDATE CASCADE,
  ADD CONSTRAINT `speisekarte_ibfk_3` FOREIGN KEY (`FIDUnterkategorie`) REFERENCES `unterkategorie` (`IDUnterkategorie`) ON UPDATE CASCADE,
  ADD CONSTRAINT `speisekarte_ibfk_4` FOREIGN KEY (`FIDGericht`) REFERENCES `gerichte` (`IDGericht`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
